from ._queries import (
    biomart_annotations,
    gene_coordinates,
    mitochondrial_genes,
)  # Biomart queries
from ._queries import enrich  # gprofiler queries
